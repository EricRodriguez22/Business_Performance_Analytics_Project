This is the group project folder for <insert your names here>
